package net.sf.yacas;


/* Temporary place to put routines we want to place in the scripts eventually.
*/
public class TempMathUtils
{

}
