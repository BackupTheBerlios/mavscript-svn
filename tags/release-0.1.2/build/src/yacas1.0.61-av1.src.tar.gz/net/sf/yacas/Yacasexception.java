package net.sf.yacas;


class Yacasexception extends Exception
{
  public Yacasexception(String message)
  {
    super(message);
  }
}
