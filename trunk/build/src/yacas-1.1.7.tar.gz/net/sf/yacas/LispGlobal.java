package net.sf.yacas;


class LispGlobal extends LispAssociatedHash // <LispGlobalVariable>
{
}

