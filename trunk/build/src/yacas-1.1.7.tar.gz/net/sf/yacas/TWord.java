package net.sf.yacas;

class TWord
{
  public String word = new String();
  public String digits = new String();
};
