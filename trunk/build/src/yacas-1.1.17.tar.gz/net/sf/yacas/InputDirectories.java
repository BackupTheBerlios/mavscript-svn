package net.sf.yacas;

class InputDirectories extends java.util.ArrayList // CDeletingArrayGrower<LispStringPtr>
{
}
