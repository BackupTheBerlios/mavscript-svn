package net.sf.yacas;
class CVersion { static String VERSION = "1.0.61"; }
