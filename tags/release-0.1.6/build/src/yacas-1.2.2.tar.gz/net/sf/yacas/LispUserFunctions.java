package net.sf.yacas;


/// Associated hash of LispMultiUserFunction objects.

class LispUserFunctions extends LispAssociatedHash // <LispMultiUserFunction>
{
}
