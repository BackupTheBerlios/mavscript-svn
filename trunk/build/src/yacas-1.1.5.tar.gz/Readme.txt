Instruction for compiling yacas (java version)
-------------------------------

From yacas tarball
------------------
Get yacas*.tar.gz from http://yacas.sf.net. Unpack.

./configure
make
cd JavaYacas
make -f makefile.yacas

Put the created file yacas.jar to mavscript/lib.



From the source included in mavscript
-------------------------------------
1) Create a temporary directory and cd into it.
2) Unpack yacas.jar from mavscript/lib. (It contains the yacas script files.)
3) Remove subdirectory net. (It contains the binaries you want to recompile from source.)
4) Unpack yacas*.tar.gz from mavscript/src
5) mv net/sf/yacas/CommonLispTokenizer.java net/sf/yacas/CommonLispTokenizer.java.stub
6) javac net/sf/yacas/*.java
7) jar -cmf MANIFEST.MF yacas.jar *

Put the created file yacas.jar to mavscript/lib.