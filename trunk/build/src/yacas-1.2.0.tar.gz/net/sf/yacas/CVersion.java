package net.sf.yacas;
class CVersion { static String VERSION = "1.2.0"; }
