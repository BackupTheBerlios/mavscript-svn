package net.sf.yacas;
class CVersion { static String VERSION = "1.1.0"; }
