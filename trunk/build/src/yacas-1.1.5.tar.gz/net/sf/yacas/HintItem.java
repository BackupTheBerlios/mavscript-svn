package net.sf.yacas;

class HintItem
{
    public  String base;
    public  String hint;
    public  String description;
};
